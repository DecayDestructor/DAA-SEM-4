#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_VERTICES 20

// Structure to represent a graph
typedef struct {
    int V;
    int adj[MAX_VERTICES][MAX_VERTICES];
} Graph;

// Structure to store a vertex and its key value
typedef struct {
    int vertex, key;
} MinHeapNode;

// Structure for Min Heap
typedef struct {
    MinHeapNode heap[MAX_VERTICES];
    int size;
} MinHeap;

// Swap function
void swap(MinHeapNode *a, MinHeapNode *b) {
    MinHeapNode temp = *a;
    *a = *b;
    *b = temp;
}

// Heapify function
void minHeapify(MinHeap *heap, int index) {
    int smallest = index;
    int left = 2 * index + 1, right = 2 * index + 2;

    if (left < heap->size && heap->heap[left].key < heap->heap[smallest].key)
        smallest = left;
    if (right < heap->size && heap->heap[right].key < heap->heap[smallest].key)
        smallest = right;

    if (smallest != index) {
        swap(&heap->heap[index], &heap->heap[smallest]);
        minHeapify(heap, smallest);
    }
}

// Extract the minimum key vertex from Min Heap
MinHeapNode extractMin(MinHeap *heap) {
    MinHeapNode min = heap->heap[0];
    heap->heap[0] = heap->heap[--heap->size];
    minHeapify(heap, 0);
    return min;
}

// Function to update the key value in the Min Heap
void decreaseKey(MinHeap *heap, int vertex, int newKey) {
    int i;
    for (i = 0; i < heap->size; i++) {
        if (heap->heap[i].vertex == vertex) {
            heap->heap[i].key = newKey;
            break;
        }
    }

    while (i && heap->heap[(i - 1) / 2].key > heap->heap[i].key) {
        swap(&heap->heap[i], &heap->heap[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

// Prim’s Algorithm Using Min Heap
void primMST(Graph *graph, FILE *file, int v) {
    int parent[MAX_VERTICES], key[MAX_VERTICES], inMST[MAX_VERTICES];
    MinHeap heap = {.size = graph->V};
    clock_t start, end;
    double cpu_time_used;

    for (int i = 0; i < graph->V; i++) {
        key[i] = INT_MAX;
        inMST[i] = 0;
        heap.heap[i].vertex = i;
        heap.heap[i].key = key[i];
    }

    key[0] = 0;
    parent[0] = -1;
    decreaseKey(&heap, 0, 0);

    start = clock();
    while (heap.size > 0) {
        MinHeapNode minNode = extractMin(&heap);
        int u = minNode.vertex;
        inMST[u] = 1;

        for (int v = 0; v < graph->V; v++) {
            if (graph->adj[u][v] && !inMST[v] && graph->adj[u][v] < key[v]) {
                key[v] = graph->adj[u][v];
                parent[v] = u;
                decreaseKey(&heap, v, key[v]);
            }
        }
    }
    end = clock();
    cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("Prim's MST for V=%d:\n", v);
    for (int i = 1; i < graph->V; i++)
        printf("%d -- %d == %d\n", parent[i], i, graph->adj[i][parent[i]]);

    fprintf(file, "%d,Prim,%.6f\n", v, cpu_time_used);
}

// Function to generate a random graph
Graph generateRandomGraph(int V) {
    Graph graph;
    graph.V = V;
    srand(time(0));

    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            if (i != j)
                graph.adj[i][j] = rand() % 100 + 1;
            else
                graph.adj[i][j] = 0;
        }
    }
    return graph;
}

// Main function
int main() {
    FILE *file = fopen("mst_timings_prim.csv", "w");
    fprintf(file, "Vertices,Algorithm,Time (seconds)\n");

    int sizes[] = {8, 15, 20, 12};
    for (int i = 0; i < 4; i++) {
        int V = sizes[i];
        Graph graph = generateRandomGraph(V);
        primMST(&graph, file, V);
    }

    fclose(file);
    return 0;
}
