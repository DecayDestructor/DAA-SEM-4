#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_EDGES 100
#define MAX_VERTICES 20

// Structure to represent an edge
typedef struct {
    int src, dest, weight;
} Edge;

// Structure to represent a graph
typedef struct {
    int V, E;
    Edge edges[MAX_EDGES];
} Graph;

// Structure for Min Heap (Priority Queue)
typedef struct {
    Edge heap[MAX_EDGES];
    int size;
} MinHeap;

// Swap function for heap
void swap(Edge *a, Edge *b) {
    Edge temp = *a;
    *a = *b;
    *b = temp;
}

// Heapify function
void minHeapify(MinHeap *heap, int index) {
    int smallest = index;
    int left = 2 * index + 1;
    int right = 2 * index + 2;

    if (left < heap->size && heap->heap[left].weight < heap->heap[smallest].weight)
        smallest = left;

    if (right < heap->size && heap->heap[right].weight < heap->heap[smallest].weight)
        smallest = right;

    if (smallest != index) {
        swap(&heap->heap[index], &heap->heap[smallest]);
        minHeapify(heap, smallest);
    }
}

// Extract minimum edge from the heap
Edge extractMin(MinHeap *heap) {
    Edge minEdge = heap->heap[0];
    heap->heap[0] = heap->heap[--heap->size];
    minHeapify(heap, 0);
    return minEdge;
}

// Insert edge into the heap
void insertHeap(MinHeap *heap, Edge edge) {
    int i = heap->size++;
    heap->heap[i] = edge;

    while (i && heap->heap[(i - 1) / 2].weight > heap->heap[i].weight) {
        swap(&heap->heap[i], &heap->heap[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

// Structure to represent a subset for Union-Find
typedef struct {
    int parent, rank;
} Subset;

// Find function with path compression
int find(Subset subsets[], int i) {
    if (subsets[i].parent != i)
        subsets[i].parent = find(subsets, subsets[i].parent);
    return subsets[i].parent;
}

// Union function with rank heuristic
void unionSets(Subset subsets[], int x, int y) {
    int rootX = find(subsets, x);
    int rootY = find(subsets, y);

    if (subsets[rootX].rank < subsets[rootY].rank)
        subsets[rootX].parent = rootY;
    else if (subsets[rootX].rank > subsets[rootY].rank)
        subsets[rootY].parent = rootX;
    else {
        subsets[rootY].parent = rootX;
        subsets[rootX].rank++;
    }
}

// Kruskal's Algorithm Using Min Heap
void kruskalMST(Graph *graph, FILE *file, int v) {
    Edge result[MAX_VERTICES];
    int e = 0;
    MinHeap heap = {.size = 0};
    clock_t start, end;
    double cpu_time_used;

    // Insert all edges into the heap
    for (int i = 0; i < graph->E; i++)
        insertHeap(&heap, graph->edges[i]);

    Subset subsets[MAX_VERTICES];
    for (int v = 0; v < graph->V; ++v) {
        subsets[v].parent = v;
        subsets[v].rank = 0;
    }

    start = clock();
    while (e < graph->V - 1 && heap.size > 0) {
        Edge nextEdge = extractMin(&heap);
        int x = find(subsets, nextEdge.src);
        int y = find(subsets, nextEdge.dest);

        if (x != y) {
            result[e++] = nextEdge;
            unionSets(subsets, x, y);
        }
    }
    end = clock();
    cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("Kruskal's MST for V=%d:\n", v);
    for (int i = 0; i < e; ++i)
        printf("%d -- %d == %d\n", result[i].src, result[i].dest, result[i].weight);
    fprintf(file, "%d,Kruskal,%.6f\n", v, cpu_time_used);
}

// Function to generate a random graph
Graph generateRandomGraph(int V, int E) {
    Graph graph;
    graph.V = V;
    graph.E = E;
    srand(time(0));

    for (int i = 0; i < E; i++) {
        graph.edges[i].src = rand() % V;
        graph.edges[i].dest = rand() % V;
        graph.edges[i].weight = rand() % 100 + 1;
    }
    return graph;
}

// Main function
int main() {
    FILE *file = fopen("mst_timings.csv", "w");
    fprintf(file, "Vertices,Algorithm,Time (seconds)\n");

    int sizes[] = {8, 15, 20, 12};
    for (int i = 0; i < 4; i++) {
        int V = sizes[i];
        Graph graph = generateRandomGraph(V, V * 2);
        kruskalMST(&graph, file, V);
    }

    fclose(file);
    return 0;
}
