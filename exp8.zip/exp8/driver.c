#include <stdbool.h>
#include <stdio.h>

#define MAX 100

int w[MAX];     // Array to store the weights
int x[MAX];     // Array to store the inclusion status (1=included, 0=excluded)
int n;          // Number of elements
int m;          // Target sum
int total = 0;  // Total sum of remaining elements

// Function to print the subset
void printSubset() {
    printf("{ ");
    for (int i = 1; i <= n; i++) {
        if (x[i] == 1) {
            printf("%d ", w[i]);
        }
    }
    printf("}\n");
}

// Function to check if a subset with given sum exists
void sumOfSubsets(int s, int k, int r) {
    x[k] = 1;  // Include the k-th element

    if (s + w[k] == m) {
        printSubset();
    } else if (s + w[k] + w[k + 1] <= m) {
        sumOfSubsets(s + w[k], k + 1, r - w[k]);
    }

    x[k] = 0;  // Exclude the k-th element

    if ((s + r - w[k] >= m) && (s + w[k + 1] <= m)) {
        sumOfSubsets(s, k + 1, r - w[k]);
    }
}

int main() {
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    printf("Enter the elements in increasing order:\n");
    for (int i = 1; i <= n; i++) {
        scanf("%d", &w[i]);
        total += w[i];
    }

    printf("Enter the target sum: ");
    scanf("%d", &m);

    printf("\nThe subsets with sum %d are:\n", m);
    sumOfSubsets(0, 1, total);

    return 0;
}