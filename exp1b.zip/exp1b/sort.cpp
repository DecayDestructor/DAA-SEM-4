#include <chrono>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;
using namespace std::chrono;

// Function to generate and save 100000 random numbers
void generateNumbers(const string &filename, int count) {
    ofstream file(filename);
    srand(time(0));
    for (int i = 0; i < count; i++) {
        file << rand() % 1000000 << " ";
    }
    file.close();
}

// Function to read numbers from file
vector<int> readNumbers(const string &filename, int count) {
    ifstream file(filename);
    vector<int> numbers(count);
    for (int i = 0; i < count; i++) {
        file >> numbers[i];
    }
    file.close();
    return numbers;
}

// Insertion Sort
void insertionSort(vector<int> &arr, int n) {
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

// Selection Sort
void selectionSort(vector<int> &arr, int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIdx]) {
                minIdx = j;
            }
        }
        swap(arr[i], arr[minIdx]);
    }
}

// Function to measure execution time
long long measureSortTime(void (*sortFunc)(vector<int> &, int), vector<int> &arr, int n) {
    auto start = high_resolution_clock::now();
    sortFunc(arr, n);
    auto stop = high_resolution_clock::now();
    return duration_cast<milliseconds>(stop - start).count();
}

int main() {
    string filename = "numbers.txt";
    int totalNumbers = 100000;
    generateNumbers(filename, totalNumbers);

    ofstream resultFile("sorting_results.csv");
    resultFile << "Block Size,Insertion Sort (ms),Selection Sort (ms)\n";

    for (int blockSize = 100; blockSize <= totalNumbers; blockSize += 100) {
        vector<int> numbers = readNumbers(filename, blockSize);

        vector<int> copy1 = numbers, copy2 = numbers;
        long long insertionTime = measureSortTime(insertionSort, copy1, blockSize);
        long long selectionTime = measureSortTime(selectionSort, copy2, blockSize);

        resultFile << blockSize << "," << insertionTime << "," << selectionTime << "\n";
        cout << "Sorted " << blockSize << " elements: Insertion Sort = " << insertionTime
             << " ms, Selection Sort = " << selectionTime << " ms" << endl;
    }

    resultFile.close();
    cout << "Results saved in sorting_results.csv" << endl;
    return 0;
}
