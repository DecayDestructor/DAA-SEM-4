#include <bits/stdc++.h>

#include <chrono>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;
using namespace std::chrono;

#define PRIME 1000000007

// Function to calculate hash value of a string
long long createHash(const string &str, int len) {
    long long hash = 0;
    for (int i = 0; i < len; i++) {
        hash = (hash * 53 + str[i]) % PRIME;
    }
    return hash;
}

// Function to recalculate hash (Rolling Hash)
long long recalculateHash(long long oldHash, char oldChar, char newChar, int patternLen) {
    long long newHash = (oldHash - oldChar * pow(256, patternLen - 1)) * 256 + newChar;
    newHash %= PRIME;
    if (newHash < 0) newHash += PRIME;
    return newHash;
}

// Rabin-Karp algorithm
vector<int> rabinKarpSearch(const string &text, const string &pattern) {
    int textLen = text.size(), patternLen = pattern.size();
    long long patternHash = createHash(pattern, patternLen);
    long long textHash = createHash(text, patternLen);
    vector<int> positions;

    for (int i = 0; i <= textLen - patternLen; i++) {
        if (patternHash == textHash) {
            if (text.substr(i, patternLen) == pattern)
                positions.push_back(i);
        }
        if (i < textLen - patternLen)
            textHash = recalculateHash(textHash, text[i], text[i + patternLen], patternLen);
    }
    return positions;
}

int main() {
    vector<string> textFiles = {"text1.txt", "text2.txt", "text3.txt", "text4.txt", "text5.txt", "text6.txt", "text7.txt", "text8.txt", "text9.txt", "text10.txt"};
    vector<string> patternFiles = {"pattern1.txt", "pattern2.txt", "pattern3.txt", "pattern4.txt", "pattern5.txt", "pattern6.txt", "pattern7.txt", "pattern8.txt", "pattern9.txt", "pattern10.txt"};
    vector<int> patternSizes = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

    ofstream output("output_times.csv");
    output << "Pattern Size, Text File, Time Taken (ms)\n";

    for (int t = 0; t < textFiles.size(); t++) {
        ifstream textStream(textFiles[t]);
        string text((istreambuf_iterator<char>(textStream)), istreambuf_iterator<char>());
        textStream.close();

        for (int p = 0; p < patternFiles.size(); p++) {
            ifstream patternStream(patternFiles[p]);
            string pattern((istreambuf_iterator<char>(patternStream)), istreambuf_iterator<char>());
            patternStream.close();

            auto start = high_resolution_clock::now();
            vector<int> positions = rabinKarpSearch(text, pattern);
            auto stop = high_resolution_clock::now();
            auto duration = duration_cast<milliseconds>(stop - start);

            output << patternSizes[p] << ", " << textFiles[t] << ", " << duration.count() << "\n";
        }
    }

    output.close();
    cout << "Pattern matching completed. Results saved in output_times.csv" << endl;
    return 0;
}
