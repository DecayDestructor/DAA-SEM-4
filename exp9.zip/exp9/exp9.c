#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 4
#define MAX_HEAP 10000

typedef struct Node {
    int mat[N][N];
    int x, y;
    int cost;
    int level;
    struct Node* parent;
} Node;

int row[] = {1, -1, 0, 0};
int col[] = {0, 0, -1, 1};

int final[N][N] = {
    {1, 2, 3, 4},
    {5, 6, 7, 8},
    {9, 10, 11, 12},
    {13, 14, 15, 0}};

Node* newNode(int mat[N][N], int x, int y, int newX, int newY, int level, Node* parent) {
    Node* node = (Node*)malloc(sizeof(Node));
    memcpy(node->mat, mat, sizeof(node->mat));
    int temp = node->mat[x][y];
    node->mat[x][y] = node->mat[newX][newY];
    node->mat[newX][newY] = temp;
    node->x = newX;
    node->y = newY;
    node->level = level;
    node->parent = parent;
    node->cost = INT_MAX;
    return node;
}

int calculateCost(int mat[N][N]) {
    int cost = 0;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            if (mat[i][j] != 0) {
                int val = mat[i][j] - 1;
                cost += abs(i - val / N) + abs(j - val % N);
            }
    return cost;
}

int isSafe(int x, int y) {
    return x >= 0 && x < N && y >= 0 && y < N;
}

void printMatrix(int mat[N][N]) {
    for (int i = 0; i < N; i++, printf("\n"))
        for (int j = 0; j < N; j++)
            printf("%2d ", mat[i][j]);
    printf("\n");
}

void printPath(Node* root) {
    if (root == NULL) return;
    printPath(root->parent);
    printMatrix(root->mat);
}

// ---------------- MIN HEAP IMPLEMENTATION ---------------- //

Node* heap[MAX_HEAP];
int heapSize = 0;

int getPriority(Node* node) {
    return node->cost + node->level;
}

void swap(int i, int j) {
    Node* temp = heap[i];
    heap[i] = heap[j];
    heap[j] = temp;
}

void heapifyUp(int i) {
    while (i && getPriority(heap[i]) < getPriority(heap[(i - 1) / 2])) {
        swap(i, (i - 1) / 2);
        i = (i - 1) / 2;
    }
}

void heapifyDown(int i) {
    int smallest = i;
    int left = 2 * i + 1, right = 2 * i + 2;

    if (left < heapSize && getPriority(heap[left]) < getPriority(heap[smallest]))
        smallest = left;
    if (right < heapSize && getPriority(heap[right]) < getPriority(heap[smallest]))
        smallest = right;

    if (smallest != i) {
        swap(i, smallest);
        heapifyDown(smallest);
    }
}

void push(Node* node) {
    if (heapSize >= MAX_HEAP) return;
    heap[heapSize] = node;
    heapifyUp(heapSize);
    heapSize++;
}

Node* pop() {
    if (heapSize <= 0) return NULL;
    Node* top = heap[0];
    heap[0] = heap[--heapSize];
    heapifyDown(0);
    return top;
}

int isHeapEmpty() {
    return heapSize == 0;
}

// ---------------- BRANCH AND BOUND SOLVER ---------------- //

void solve(int initial[N][N], int x, int y) {
    Node* root = newNode(initial, x, y, x, y, 0, NULL);
    root->cost = calculateCost(initial);
    push(root);

    while (!isHeapEmpty()) {
        Node* min = pop();

        if (min->cost == 0) {
            printf("Solution found in %d moves:\n\n", min->level);
            printPath(min);
            return;
        }

        for (int i = 0; i < 4; i++) {
            int newX = min->x + row[i];
            int newY = min->y + col[i];

            if (isSafe(newX, newY)) {
                Node* child = newNode(min->mat, min->x, min->y, newX, newY, min->level + 1, min);
                child->cost = calculateCost(child->mat);
                push(child);
            }
        }
    }
}

// ---------------- MAIN FUNCTION ---------------- //

int main() {
    int initial[N][N] = {
        {1, 2, 3, 4},
        {5, 6, 0, 8},
        {9, 10, 7, 12},
        {13, 14, 11, 15}};

    int x = 1, y = 2;  // Position of blank tile
    solve(initial, x, y);
    return 0;
}
