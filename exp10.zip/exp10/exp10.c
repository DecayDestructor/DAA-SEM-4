#include <stdbool.h>
#include <stdio.h>

#define MAX 100

// Edge structure
typedef struct {
    int u, v;
    bool removed;
} Edge;

int main() {
    int V, E;
    Edge edges[MAX];
    bool visited[MAX] = {false};
    int vertexCover[MAX];
    int coverSize = 0;

    // Input number of vertices and edges
    printf("Enter number of vertices: ");
    scanf("%d", &V);
    printf("Enter number of edges: ");
    scanf("%d", &E);

    printf("Enter the edges (u v):\n");
    for (int i = 0; i < E; i++) {
        scanf("%d %d", &edges[i].u, &edges[i].v);
        edges[i].removed = false;
    }

    // Approximate Vertex Cover Algorithm
    for (int i = 0; i < E; i++) {
        if (!edges[i].removed) {
            int u = edges[i].u;
            int v = edges[i].v;

            // Add both vertices to cover
            if (!visited[u]) {
                vertexCover[coverSize++] = u;
                visited[u] = true;
            }
            if (!visited[v]) {
                vertexCover[coverSize++] = v;
                visited[v] = true;
            }

            // Remove all edges incident on u or v
            for (int j = 0; j < E; j++) {
                if (!edges[j].removed &&
                    (edges[j].u == u || edges[j].v == u || edges[j].u == v || edges[j].v == v)) {
                    edges[j].removed = true;
                }
            }
        }
    }

    // Output the vertex cover
    printf("\nApproximate Vertex Cover:\n");
    for (int i = 0; i < coverSize; i++) {
        printf("%d ", vertexCover[i]);
    }
    printf("\n");

    return 0;
}
