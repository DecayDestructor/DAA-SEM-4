import random
import matplotlib.pyplot as plt
import numpy as np


def generate_points(n=100, range_min=1, range_max=100):
    points = [
        (random.randint(range_min, range_max), random.randint(range_min, range_max))
        for _ in range(n)
    ]
    with open("points.txt", "w") as f:
        for p in points:
            f.write(f"{p[0]} {p[1]}\n")
    return points


# Brute Force Convex Hull
def brute_force_hull(points):
    def is_left_turn(p, q, r):
        return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0]) > 0

    hull = set()
    n = len(points)
    for i in range(n):
        for j in range(i + 1, n):
            left, right = False, False
            for k in range(n):
                if k == i or k == j:
                    continue
                if is_left_turn(points[i], points[j], points[k]):
                    left = True
                else:
                    right = True
            if left != right:
                hull.add(points[i])
                hull.add(points[j])
    return sorted(hull)


# Graham's Scan Convex Hull
def graham_scan(points):
    def orientation(p, q, r):
        return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])

    points.sort()  # Sort by x, then y
    lower, upper = [], []

    for p in points:
        while len(lower) >= 2 and orientation(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)

    for p in reversed(points):
        while len(upper) >= 2 and orientation(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)

    return lower[:-1] + upper[:-1]


# Divide and Conquer Convex Hull
def divide_and_conquer(points):
    def merge(left, right):
        points = left + right
        return graham_scan(points)

    if len(points) <= 5:
        return graham_scan(points)

    mid = len(points) // 2
    left_hull = divide_and_conquer(points[:mid])
    right_hull = divide_and_conquer(points[mid:])
    return merge(left_hull, right_hull)


def plot_hull(points, hull, title):
    x, y = zip(*points)
    plt.scatter(x, y, label="Points")

    hull.append(hull[0])  # Close the convex hull
    hx, hy = zip(*hull)
    plt.plot(hx, hy, "r-", label="Convex Hull")

    plt.title(title)
    plt.legend()
    plt.show()


def save_hull(hull, filename):
    with open(filename, "w") as f:
        for p in hull:
            f.write(f"{p[0]} {p[1]}\n")


def main():
    points = generate_points()

    hull1 = brute_force_hull(points)
    hull2 = graham_scan(points)
    hull3 = divide_and_conquer(points)

    save_hull(hull1, "brute_force_hull.txt")
    save_hull(hull2, "graham_scan_hull.txt")
    save_hull(hull3, "divide_and_conquer_hull.txt")

    plot_hull(points, hull1, "Brute Force Convex Hull")
    plot_hull(points, hull2, "Graham's Scan Convex Hull")
    plot_hull(points, hull3, "Divide and Conquer Convex Hull")


if __name__ == "__main__":
    main()
