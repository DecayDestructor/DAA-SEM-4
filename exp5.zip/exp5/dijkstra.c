#include <limits.h>
#include <stdio.h>
#define V 100

void dijkstra(int graph[V][V], int n, int src) {
    int dist[V], visited[V];
    FILE *fout = fopen("output.txt", "w");  // Open file to write

    for (int i = 0; i < n; i++) {
        dist[i] = INT_MAX;
        visited[i] = 0;
    }
    dist[src] = 0;

    for (int count = 0; count < n - 1; count++) {
        int min = INT_MAX, u;
        for (int v = 0; v < n; v++)
            if (!visited[v] && dist[v] <= min)
                min = dist[v], u = v;

        visited[u] = 1;

        for (int v = 0; v < n; v++)
            if (!visited[v] && graph[u][v] && dist[u] != INT_MAX && dist[u] + graph[u][v] < dist[v])
                dist[v] = dist[u] + graph[u][v];
    }

    fprintf(fout, "Vertex \t Distance from Source\n");
    for (int i = 0; i < n; i++)
        fprintf(fout, "%d \t %d\n", i, dist[i]);

    fclose(fout);  // Close file
}

int main() {
    int n, src;
    printf("Enter number of vertices: ");
    scanf("%d", &n);
    int graph[V][V];

    printf("Enter adjacency matrix:\n");
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            scanf("%d", &graph[i][j]);

    printf("Enter source vertex: ");
    scanf("%d", &src);

    dijkstra(graph, n, src);
    printf("Output saved to output.txt\n");
    return 0;
}
