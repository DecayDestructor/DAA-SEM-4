#include <limits.h>
#include <stdio.h>

#define V 100   // Maximum number of vertices
#define E 1000  // Maximum number of edges

struct Edge {
    int src, dest, weight;
};

void bellmanFord(struct Edge edges[], int n, int m, int src) {
    int dist[V];
    FILE *fout = fopen("outputBF.txt", "w");

    for (int i = 0; i < n; i++)
        dist[i] = INT_MAX;
    dist[src] = 0;

    for (int i = 1; i <= n - 1; i++) {
        for (int j = 0; j < m; j++) {
            int u = edges[j].src, v = edges[j].dest, weight = edges[j].weight;
            if (dist[u] != INT_MAX && dist[u] + weight < dist[v])
                dist[v] = dist[u] + weight;
        }
    }

    for (int j = 0; j < m; j++) {
        int u = edges[j].src, v = edges[j].dest, weight = edges[j].weight;
        if (dist[u] != INT_MAX && dist[u] + weight < dist[v]) {
            fprintf(fout, "Graph contains negative weight cycle\n");
            fclose(fout);
            return;
        }
    }

    fprintf(fout, "Vertex \t Distance from Source\n");
    for (int i = 0; i < n; i++)
        fprintf(fout, "%d \t %d\n", i, dist[i]);

    fclose(fout);
}

int main() {
    int n, m, src;
    printf("Enter number of vertices and edges: ");
    scanf("%d %d", &n, &m);
    struct Edge edges[E];

    printf("Enter edges (source destination weight):\n");
    for (int i = 0; i < m; i++)
        scanf("%d %d %d", &edges[i].src, &edges[i].dest, &edges[i].weight);

    printf("Enter source vertex: ");
    scanf("%d", &src);
    bellmanFord(edges, n, m, src);
    return 0;
}
