#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structure to represent a graph edge
struct Edge {
    int v;             // Target vertex
    int capacity;      // Capacity of the edge
    int flow;          // Current flow through the edge
    struct Edge* rev;  // Pointer to reverse edge
};

// Structure to represent a vertex (node)
struct Vertex {
    struct Edge** edges;       // Array of edges from this vertex
    int edge_count;            // Number of edges from this vertex
    int visited;               // For BFS/DFS
    int parent;                // For path reconstruction
    struct Edge* parent_edge;  // Edge used to reach this vertex
};

// Structure to represent the graph
struct Graph {
    int vertex_count;         // Number of vertices
    struct Vertex* vertices;  // Array of vertices
};

// Function to create a new graph with given number of vertices
struct Graph* create_graph(int vertex_count) {
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->vertex_count = vertex_count;
    graph->vertices = (struct Vertex*)malloc(vertex_count * sizeof(struct Vertex));

    for (int i = 0; i < vertex_count; i++) {
        graph->vertices[i].edges = NULL;
        graph->vertices[i].edge_count = 0;
        graph->vertices[i].visited = 0;
        graph->vertices[i].parent = -1;
        graph->vertices[i].parent_edge = NULL;
    }

    return graph;
}

// Function to add an edge to the graph
void add_edge(struct Graph* graph, int u, int v, int capacity) {
    // Create forward edge (u -> v)
    struct Edge* forward = (struct Edge*)malloc(sizeof(struct Edge));
    forward->v = v;
    forward->capacity = capacity;
    forward->flow = 0;

    // Create reverse edge (v -> u) with 0 capacity initially
    struct Edge* backward = (struct Edge*)malloc(sizeof(struct Edge));
    backward->v = u;
    backward->capacity = 0;
    backward->flow = 0;

    // Set reverse pointers
    forward->rev = backward;
    backward->rev = forward;

    // Add forward edge to u's edge list
    graph->vertices[u].edge_count++;
    graph->vertices[u].edges = (struct Edge**)realloc(graph->vertices[u].edges,
                                                      graph->vertices[u].edge_count * sizeof(struct Edge*));
    graph->vertices[u].edges[graph->vertices[u].edge_count - 1] = forward;

    // Add backward edge to v's edge list
    graph->vertices[v].edge_count++;
    graph->vertices[v].edges = (struct Edge**)realloc(graph->vertices[v].edges,
                                                      graph->vertices[v].edge_count * sizeof(struct Edge*));
    graph->vertices[v].edges[graph->vertices[v].edge_count - 1] = backward;
}

// BFS to find augmenting path from source to sink
bool bfs(struct Graph* graph, int source, int sink) {
    // Reset visited and parent information
    for (int i = 0; i < graph->vertex_count; i++) {
        graph->vertices[i].visited = 0;
        graph->vertices[i].parent = -1;
        graph->vertices[i].parent_edge = NULL;
    }

    // Simple queue implementation for BFS
    int* queue = (int*)malloc(graph->vertex_count * sizeof(int));
    int front = 0, rear = 0;

    // Start with source
    queue[rear++] = source;
    graph->vertices[source].visited = 1;

    while (front < rear) {
        int u = queue[front++];

        // Explore all edges from u
        for (int i = 0; i < graph->vertices[u].edge_count; i++) {
            struct Edge* e = graph->vertices[u].edges[i];
            int v = e->v;

            // If vertex v is not visited and there's residual capacity
            if (!graph->vertices[v].visited && e->capacity > e->flow) {
                graph->vertices[v].visited = 1;
                graph->vertices[v].parent = u;
                graph->vertices[v].parent_edge = e;
                queue[rear++] = v;

                // If we reached the sink, we're done
                if (v == sink) {
                    free(queue);
                    return true;
                }
            }
        }
    }

    free(queue);
    return false;
}

// Ford-Fulkerson algorithm to find maximum flow
int ford_fulkerson(struct Graph* graph, int source, int sink) {
    int max_flow = 0;

    // Augment the flow while there is a path from source to sink
    while (bfs(graph, source, sink)) {
        // Find the minimum residual capacity along the path
        int path_flow = INT_MAX;
        for (int v = sink; v != source; v = graph->vertices[v].parent) {
            struct Edge* e = graph->vertices[v].parent_edge;
            path_flow = (path_flow < e->capacity - e->flow) ? path_flow : (e->capacity - e->flow);
        }

        // Update residual capacities of the edges and reverse edges
        for (int v = sink; v != source; v = graph->vertices[v].parent) {
            struct Edge* e = graph->vertices[v].parent_edge;
            e->flow += path_flow;
            e->rev->flow -= path_flow;
        }

        // Add path flow to overall flow
        max_flow += path_flow;
    }

    return max_flow;
}

// Function to print the graph to file
void print_graph_to_file(struct Graph* graph, FILE* file) {
    fprintf(file, "Graph with %d vertices:\n", graph->vertex_count);
    for (int u = 0; u < graph->vertex_count; u++) {
        fprintf(file, "Vertex %d -> ", u);
        for (int i = 0; i < graph->vertices[u].edge_count; i++) {
            struct Edge* e = graph->vertices[u].edges[i];
            fprintf(file, "%d (%d/%d), ", e->v, e->flow, e->capacity);
        }
        fprintf(file, "\n");
    }
}

// Function to free memory allocated for the graph
void free_graph(struct Graph* graph) {
    for (int i = 0; i < graph->vertex_count; i++) {
        for (int j = 0; j < graph->vertices[i].edge_count; j++) {
            free(graph->vertices[i].edges[j]);
        }
        free(graph->vertices[i].edges);
    }
    free(graph->vertices);
    free(graph);
}

int main() {
    // Open output file
    FILE* output_file = fopen("ford_fulkerson_output.txt", "w");
    if (output_file == NULL) {
        printf("Error opening output file!\n");
        return 1;
    }

    // Example graph with 20 vertices (0-19)
    int vertex_count = 20;
    struct Graph* graph = create_graph(vertex_count);

    // Adding edges with capacities (example network)
    // Source is 0, Sink is 19

    // Layer 1: Source to intermediate nodes
    add_edge(graph, 0, 1, 10);
    add_edge(graph, 0, 2, 5);
    add_edge(graph, 0, 3, 15);

    // Layer 2: First intermediate layer
    add_edge(graph, 1, 4, 9);
    add_edge(graph, 1, 5, 4);
    add_edge(graph, 1, 6, 15);
    add_edge(graph, 2, 4, 4);
    add_edge(graph, 2, 5, 8);
    add_edge(graph, 3, 6, 16);
    add_edge(graph, 3, 7, 6);

    // Layer 3: Second intermediate layer
    add_edge(graph, 4, 8, 10);
    add_edge(graph, 4, 9, 15);
    add_edge(graph, 5, 9, 15);
    add_edge(graph, 5, 10, 8);
    add_edge(graph, 6, 10, 15);
    add_edge(graph, 6, 11, 6);
    add_edge(graph, 7, 11, 10);
    add_edge(graph, 7, 12, 10);

    // Layer 4: Third intermediate layer
    add_edge(graph, 8, 13, 10);
    add_edge(graph, 8, 14, 5);
    add_edge(graph, 9, 14, 4);
    add_edge(graph, 9, 15, 8);
    add_edge(graph, 10, 15, 15);
    add_edge(graph, 10, 16, 6);
    add_edge(graph, 11, 16, 10);
    add_edge(graph, 11, 17, 10);
    add_edge(graph, 12, 17, 5);

    // Layer 5: Fourth intermediate layer to sink
    add_edge(graph, 13, 18, 10);
    add_edge(graph, 14, 18, 5);
    add_edge(graph, 15, 18, 4);
    add_edge(graph, 15, 19, 10);
    add_edge(graph, 16, 19, 10);
    add_edge(graph, 17, 19, 15);
    add_edge(graph, 18, 19, 10);

    fprintf(output_file, "Initial Graph:\n");
    print_graph_to_file(graph, output_file);

    int source = 0;
    int sink = 19;
    int max_flow = ford_fulkerson(graph, source, sink);

    fprintf(output_file, "\nFinal Graph (after Ford-Fulkerson):\n");
    print_graph_to_file(graph, output_file);

    fprintf(output_file, "\nMaximum Flow from %d to %d is: %d\n", source, sink, max_flow);

    // Also print to console for verification
    printf("Results written to ford_fulkerson_output.txt\n");
    printf("Maximum Flow from %d to %d is: %d\n", source, sink, max_flow);

    // Free allocated memory
    free_graph(graph);
    fclose(output_file);

    return 0;
}