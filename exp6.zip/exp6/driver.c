#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_MATRICES 10
#define MAX_DIM 1024  // Maximum dimension (2^10)

// Structure to represent a matrix
typedef struct {
    int rows;
    int cols;
    double** data;
} Matrix;

// Function prototypes
void generateRandomDimensions(int p[], int n);
void printArray(int arr[], int size);
Matrix* createRandomMatrix(int rows, int cols);
void freeMatrix(Matrix* mat);
void printMatrix(Matrix* mat);
void matrixChainOrder(int p[], int n, int m[MAX_MATRICES][MAX_MATRICES], int s[MAX_MATRICES][MAX_MATRICES]);
void printOptimalParentheses(int s[MAX_MATRICES][MAX_MATRICES], int i, int j);
Matrix* matrixMultiply(Matrix* a, Matrix* b);
Matrix* matrixChainMultiply(Matrix* matrices[], int s[MAX_MATRICES][MAX_MATRICES], int i, int j);
Matrix* matrixAdd(Matrix* a, Matrix* b);       // Added declaration
Matrix* matrixSubtract(Matrix* a, Matrix* b);  // Added declaration
Matrix* strassenMultiply(Matrix* a, Matrix* b);
Matrix* strassenChainMultiply(Matrix* matrices[], int s[MAX_MATRICES][MAX_MATRICES], int i, int j);
void printMMatrix(int m[MAX_MATRICES][MAX_MATRICES], int n);
void printSMatrix(int s[MAX_MATRICES][MAX_MATRICES], int n);

int main() {
    srand(time(0));  // Seed random number generator

    int p[MAX_MATRICES + 1];                  // Array to store dimensions
    int m[MAX_MATRICES][MAX_MATRICES] = {0};  // m[i][j] = min multiplications for M_i to M_j
    int s[MAX_MATRICES][MAX_MATRICES] = {0};  // s[i][j] = split point for M_i to M_j

    // Part 1: Find Optimal Parenthesization
    printf("=== Part 1: Find Optimal Parenthesization ===\n");

    // Generate random dimensions (powers of 2)
    generateRandomDimensions(p, MAX_MATRICES + 1);
    printf("Generated matrix dimensions: ");
    printArray(p, MAX_MATRICES + 1);

    // Compute optimal parenthesization
    matrixChainOrder(p, MAX_MATRICES, m, s);

    // Print m matrix
    printf("\nm matrix (optimal number of multiplications):\n");
    printMMatrix(m, MAX_MATRICES);

    // Print s matrix
    printf("\ns matrix (optimal split points):\n");
    printSMatrix(s, MAX_MATRICES);

    // Print optimal parenthesization
    printf("\nOptimal parenthesization: ");
    printOptimalParentheses(s, 0, MAX_MATRICES - 1);
    printf("\n");

    // Part 2: Create matrices and multiply using regular multiplication
    printf("\n=== Part 2: Regular Matrix Multiplication ===\n");

    // Create random matrices
    Matrix* matrices[MAX_MATRICES];
    for (int i = 0; i < MAX_MATRICES; i++) {
        matrices[i] = createRandomMatrix(p[i], p[i + 1]);
    }

    // Time trivial sequence ((((M1*M2)*M3)*...)*M10)
    clock_t start = clock();
    Matrix* result = matrices[0];
    for (int i = 1; i < MAX_MATRICES; i++) {
        Matrix* temp = matrixMultiply(result, matrices[i]);
        if (i > 1) freeMatrix(result);  // Free previous result (except first matrix)
        result = temp;
    }
    clock_t end = clock();
    double trivial_time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Time for trivial sequence: %.6f seconds\n", trivial_time);
    freeMatrix(result);

    // Time optimal sequence
    start = clock();
    Matrix* optimal_result = matrixChainMultiply(matrices, s, 0, MAX_MATRICES - 1);
    end = clock();
    double optimal_time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Time for optimal sequence: %.6f seconds\n", optimal_time);
    freeMatrix(optimal_result);

    // Part 3: Multiply using Strassen's algorithm
    printf("\n=== Part 3: Strassen's Matrix Multiplication ===\n");

    // Time trivial sequence with Strassen
    start = clock();
    result = matrices[0];
    for (int i = 1; i < MAX_MATRICES; i++) {
        Matrix* temp = strassenMultiply(result, matrices[i]);
        if (i > 1) freeMatrix(result);  // Free previous result (except first matrix)
        result = temp;
    }
    end = clock();
    double trivial_strassen_time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Time for trivial sequence (Strassen): %.6f seconds\n", trivial_strassen_time);
    freeMatrix(result);

    // Time optimal sequence with Strassen
    start = clock();
    Matrix* optimal_strassen_result = strassenChainMultiply(matrices, s, 0, MAX_MATRICES - 1);
    end = clock();
    double optimal_strassen_time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Time for optimal sequence (Strassen): %.6f seconds\n", optimal_strassen_time);
    freeMatrix(optimal_strassen_result);

    // Free all matrices
    for (int i = 0; i < MAX_MATRICES; i++) {
        freeMatrix(matrices[i]);
    }

    return 0;
}

// Generate random dimensions that are powers of 2
void generateRandomDimensions(int p[], int n) {
    for (int i = 0; i < n; i++) {
        int power = 3 + rand() % 7;  // 2^3 (8) to 2^9 (512)
        p[i] = (int)pow(2, power);
    }
}

// Print an array
void printArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

// Create a random matrix with values between 0 and 1
Matrix* createRandomMatrix(int rows, int cols) {
    Matrix* mat = (Matrix*)malloc(sizeof(Matrix));
    mat->rows = rows;
    mat->cols = cols;
    mat->data = (double**)malloc(rows * sizeof(double*));

    for (int i = 0; i < rows; i++) {
        mat->data[i] = (double*)malloc(cols * sizeof(double));
        for (int j = 0; j < cols; j++) {
            mat->data[i][j] = (double)rand() / RAND_MAX;  // Random value between 0 and 1
        }
    }

    return mat;
}

// Free matrix memory
void freeMatrix(Matrix* mat) {
    for (int i = 0; i < mat->rows; i++) {
        free(mat->data[i]);
    }
    free(mat->data);
    free(mat);
}

// Print matrix (for debugging)
void printMatrix(Matrix* mat) {
    for (int i = 0; i < mat->rows; i++) {
        for (int j = 0; j < mat->cols; j++) {
            printf("%.2f ", mat->data[i][j]);
        }
        printf("\n");
    }
}

// Matrix Chain Order algorithm (Dynamic Programming)
void matrixChainOrder(int p[], int n, int m[MAX_MATRICES][MAX_MATRICES], int s[MAX_MATRICES][MAX_MATRICES]) {
    for (int i = 0; i < n; i++) {
        m[i][i] = 0;
    }

    for (int l = 2; l <= n; l++) {  // l is the chain length
        for (int i = 0; i < n - l + 1; i++) {
            int j = i + l - 1;
            m[i][j] = INT_MAX;

            for (int k = i; k < j; k++) {
                int q = m[i][k] + m[k + 1][j] + p[i] * p[k + 1] * p[j + 1];
                if (q < m[i][j]) {
                    m[i][j] = q;
                    s[i][j] = k;
                }
            }
        }
    }
}

// Print optimal parenthesization
void printOptimalParentheses(int s[MAX_MATRICES][MAX_MATRICES], int i, int j) {
    if (i == j) {
        printf("M%d", i + 1);
    } else {
        printf("(");
        printOptimalParentheses(s, i, s[i][j]);
        printOptimalParentheses(s, s[i][j] + 1, j);
        printf(")");
    }
}

// Regular matrix multiplication
Matrix* matrixMultiply(Matrix* a, Matrix* b) {
    if (a->cols != b->rows) {
        printf("Matrix dimensions incompatible for multiplication\n");
        return NULL;
    }

    Matrix* result = (Matrix*)malloc(sizeof(Matrix));
    result->rows = a->rows;
    result->cols = b->cols;
    result->data = (double**)malloc(result->rows * sizeof(double*));

    for (int i = 0; i < result->rows; i++) {
        result->data[i] = (double*)malloc(result->cols * sizeof(double));
        for (int j = 0; j < result->cols; j++) {
            result->data[i][j] = 0;
            for (int k = 0; k < a->cols; k++) {
                result->data[i][j] += a->data[i][k] * b->data[k][j];
            }
        }
    }

    return result;
}

// Multiply matrix chain using optimal parenthesization (regular multiplication)
Matrix* matrixChainMultiply(Matrix* matrices[], int s[MAX_MATRICES][MAX_MATRICES], int i, int j) {
    if (i == j) {
        return matrices[i];
    }

    Matrix* left = matrixChainMultiply(matrices, s, i, s[i][j]);
    Matrix* right = matrixChainMultiply(matrices, s, s[i][j] + 1, j);
    Matrix* result = matrixMultiply(left, right);

    if (i != s[i][j]) freeMatrix(left);
    if (s[i][j] + 1 != j) freeMatrix(right);

    return result;
}

// Helper function to add two matrices
Matrix* matrixAdd(Matrix* a, Matrix* b) {
    if (a->rows != b->rows || a->cols != b->cols) {
        printf("Matrix dimensions must match for addition\n");
        return NULL;
    }

    Matrix* result = createRandomMatrix(a->rows, a->cols);
    for (int i = 0; i < a->rows; i++) {
        for (int j = 0; j < a->cols; j++) {
            result->data[i][j] = a->data[i][j] + b->data[i][j];
        }
    }
    return result;
}

// Helper function to subtract two matrices
Matrix* matrixSubtract(Matrix* a, Matrix* b) {
    if (a->rows != b->rows || a->cols != b->cols) {
        printf("Matrix dimensions must match for subtraction\n");
        return NULL;
    }

    Matrix* result = createRandomMatrix(a->rows, a->cols);
    for (int i = 0; i < a->rows; i++) {
        for (int j = 0; j < a->cols; j++) {
            result->data[i][j] = a->data[i][j] - b->data[i][j];
        }
    }
    return result;
}

// Strassen's matrix multiplication (for square matrices with power of 2 dimensions)
Matrix* strassenMultiply(Matrix* a, Matrix* b) {
    // Base case: if matrices are small, use regular multiplication
    if (a->rows <= 64) {
        return matrixMultiply(a, b);
    }

    // Ensure matrices are square and dimensions are equal and power of 2
    if (a->rows != a->cols || b->rows != b->cols || a->rows != b->rows) {
        printf("Strassen's algorithm requires square matrices with equal power-of-2 dimensions\n");
        return matrixMultiply(a, b);
    }

    int n = a->rows;
    int half = n / 2;

    // Create submatrices
    Matrix* a11 = createRandomMatrix(half, half);
    Matrix* a12 = createRandomMatrix(half, half);
    Matrix* a21 = createRandomMatrix(half, half);
    Matrix* a22 = createRandomMatrix(half, half);

    Matrix* b11 = createRandomMatrix(half, half);
    Matrix* b12 = createRandomMatrix(half, half);
    Matrix* b21 = createRandomMatrix(half, half);
    Matrix* b22 = createRandomMatrix(half, half);

    // Split input matrices into submatrices
    for (int i = 0; i < half; i++) {
        for (int j = 0; j < half; j++) {
            a11->data[i][j] = a->data[i][j];
            a12->data[i][j] = a->data[i][j + half];
            a21->data[i][j] = a->data[i + half][j];
            a22->data[i][j] = a->data[i + half][j + half];

            b11->data[i][j] = b->data[i][j];
            b12->data[i][j] = b->data[i][j + half];
            b21->data[i][j] = b->data[i + half][j];
            b22->data[i][j] = b->data[i + half][j + half];
        }
    }

    // Calculate p1 to p7
    Matrix* p1 = strassenMultiply(a11, matrixSubtract(b12, b22));
    Matrix* p2 = strassenMultiply(matrixAdd(a11, a12), b22);
    Matrix* p3 = strassenMultiply(matrixAdd(a21, a22), b11);
    Matrix* p4 = strassenMultiply(a22, matrixSubtract(b21, b11));
    Matrix* p5 = strassenMultiply(matrixAdd(a11, a22), matrixAdd(b11, b22));
    Matrix* p6 = strassenMultiply(matrixSubtract(a12, a22), matrixAdd(b21, b22));
    Matrix* p7 = strassenMultiply(matrixSubtract(a11, a21), matrixAdd(b11, b12));

    // Calculate result submatrices
    Matrix* c11 = matrixAdd(matrixSubtract(matrixAdd(p5, p4), p6), p2);
    Matrix* c12 = matrixAdd(p1, p2);
    Matrix* c21 = matrixAdd(p3, p4);
    Matrix* c22 = matrixSubtract(matrixSubtract(matrixAdd(p5, p1), p3), p7);

    // Combine result submatrices into final result
    Matrix* result = createRandomMatrix(n, n);
    for (int i = 0; i < half; i++) {
        for (int j = 0; j < half; j++) {
            result->data[i][j] = c11->data[i][j];
            result->data[i][j + half] = c12->data[i][j];
            result->data[i + half][j] = c21->data[i][j];
            result->data[i + half][j + half] = c22->data[i][j];
        }
    }

    // Free all temporary matrices
    freeMatrix(a11);
    freeMatrix(a12);
    freeMatrix(a21);
    freeMatrix(a22);
    freeMatrix(b11);
    freeMatrix(b12);
    freeMatrix(b21);
    freeMatrix(b22);
    freeMatrix(p1);
    freeMatrix(p2);
    freeMatrix(p3);
    freeMatrix(p4);
    freeMatrix(p5);
    freeMatrix(p6);
    freeMatrix(p7);
    freeMatrix(c11);
    freeMatrix(c12);
    freeMatrix(c21);
    freeMatrix(c22);

    return result;
}

// Multiply matrix chain using optimal parenthesization (Strassen's multiplication)
Matrix* strassenChainMultiply(Matrix* matrices[], int s[MAX_MATRICES][MAX_MATRICES], int i, int j) {
    if (i == j) {
        return matrices[i];
    }

    Matrix* left = strassenChainMultiply(matrices, s, i, s[i][j]);
    Matrix* right = strassenChainMultiply(matrices, s, s[i][j] + 1, j);
    Matrix* result = strassenMultiply(left, right);

    if (i != s[i][j]) freeMatrix(left);
    if (s[i][j] + 1 != j) freeMatrix(right);

    return result;
}

// Print m matrix
void printMMatrix(int m[MAX_MATRICES][MAX_MATRICES], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (j < i) {
                printf("      ");
            } else {
                printf("%5d ", m[i][j]);
            }
        }
        printf("\n");
    }
}

// Print s matrix
void printSMatrix(int s[MAX_MATRICES][MAX_MATRICES], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 1; j < n; j++) {
            if (j <= i) {
                printf("   ");
            } else {
                printf("%2d ", s[i][j] + 1);  // +1 to make it 1-based index
            }
        }
        printf("\n");
    }
}