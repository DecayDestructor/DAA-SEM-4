import random
import matplotlib.pyplot as plt
import time
import numpy as np


def generate_points(n, range_min=1, range_max=100):
    return [
        (random.randint(range_min, range_max), random.randint(range_min, range_max))
        for _ in range(n)
    ]


# Brute Force Convex Hull
def brute_force_hull(points):
    def is_left_turn(p, q, r):
        return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0]) > 0

    hull = set()
    n = len(points)
    for i in range(n):
        for j in range(i + 1, n):
            left, right = False, False
            for k in range(n):
                if k == i or k == j:
                    continue
                if is_left_turn(points[i], points[j], points[k]):
                    left = True
                else:
                    right = True
            if left != right:
                hull.add(points[i])
                hull.add(points[j])
    return sorted(hull)


# Graham's Scan Convex Hull
def graham_scan(points):
    def orientation(p, q, r):
        return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])

    points.sort()  # Sort by x, then y
    lower, upper = [], []

    for p in points:
        while len(lower) >= 2 and orientation(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)

    for p in reversed(points):
        while len(upper) >= 2 and orientation(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)

    return lower[:-1] + upper[:-1]


# Divide and Conquer Convex Hull
def divide_and_conquer(points):
    def merge(left, right):
        points = left + right
        return graham_scan(points)

    if len(points) <= 5:
        return graham_scan(points)

    mid = len(points) // 2
    left_hull = divide_and_conquer(points[:mid])
    right_hull = divide_and_conquer(points[mid:])
    return merge(left_hull, right_hull)


def measure_execution_time():
    num_points = list(range(4, 101, 4))  # Test with increasing number of points
    brute_force_times = []
    graham_scan_times = []
    divide_and_conquer_times = []

    for n in num_points:
        points = generate_points(n)

        start = time.time()
        brute_force_hull(points)
        brute_force_times.append(time.time() - start)

        start = time.time()
        graham_scan(points)
        graham_scan_times.append(time.time() - start)

        start = time.time()
        divide_and_conquer(points)
        divide_and_conquer_times.append(time.time() - start)

    # Save execution times to file
    with open("execution_times.txt", "w") as f:
        for i in range(len(num_points)):
            f.write(
                f"{num_points[i]} {brute_force_times[i]:.6f} {graham_scan_times[i]:.6f} {divide_and_conquer_times[i]:.6f}\n"
            )

    # Plot execution times
    plt.plot(num_points, brute_force_times, label="Brute Force", marker="o", color="red")
    plt.plot(num_points, graham_scan_times, label="Graham's Scan", marker="s", color="blue")
    plt.plot(num_points, divide_and_conquer_times, label="Divide and Conquer", marker="^", color="green")

    plt.xlabel("Number of Points")
    plt.ylabel("Execution Time (seconds)")
    plt.title("Convex Hull Algorithm Running Time")
    plt.legend()
    plt.grid()
    plt.show()


if __name__ == "__main__":
    measure_execution_time()
