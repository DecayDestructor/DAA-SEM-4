#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MIN_SIZE 100
#define MAX_SIZE 1000
#define STEP 100

// Brute Force Method
int maxSubarrayBruteForce(int arr[], int size) {
    int maxSum = INT_MIN;
    for (int i = 0; i < size; i++) {
        for (int j = i; j < size; j++) {
            int sum = 0;
            for (int k = i; k <= j; k++) {
                sum += arr[k];
            }
            if (sum > maxSum) {
                maxSum = sum;
            }
        }
    }
    return maxSum;
}

// Divide and Conquer Method
int maxCrossingSum(int arr[], int l, int m, int h) {
    int leftSum = INT_MIN, sum = 0;
    for (int i = m; i >= l; i--) {
        sum += arr[i];
        if (sum > leftSum) leftSum = sum;
    }

    int rightSum = INT_MIN;
    sum = 0;
    for (int i = m + 1; i <= h; i++) {
        sum += arr[i];
        if (sum > rightSum) rightSum = sum;
    }

    return leftSum + rightSum;
}

int maxSubarrayDivideConquer(int arr[], int l, int h) {
    if (l == h) return arr[l];
    int m = (l + h) / 2;
    return fmax(fmax(maxSubarrayDivideConquer(arr, l, m),
                     maxSubarrayDivideConquer(arr, m + 1, h)),
                maxCrossingSum(arr, l, m, h));
}

// Kadane's Algorithm
int maxSubarrayKadane(int arr[], int size) {
    int maxSum = INT_MIN, currentSum = 0;
    for (int i = 0; i < size; i++) {
        currentSum = fmax(arr[i], currentSum + arr[i]);
        maxSum = fmax(maxSum, currentSum);
    }
    return maxSum;
}

// Main function
int main() {
    FILE *csvFile = fopen("execution_times.csv", "w");
    if (!csvFile) {
        printf("Error opening file!\n");
        return 1;
    }

    fprintf(csvFile, "Size,BruteForceTime,DivideConquerTime,KadaneTime\n");

    srand(time(NULL));

    for (int size = MIN_SIZE; size <= MAX_SIZE; size += STEP) {
        int *arr = (int *)malloc(size * sizeof(int));
        if (!arr) {
            printf("Memory allocation failed for size %d\n", size);
            continue;
        }
        for (int i = 0; i < size; i++) arr[i] = (rand() % 201) - 100;

        clock_t start, end;
        double bruteForceTime, divideConquerTime, kadaneTime;

        // Brute Force
        start = clock();
        int bruteForceMax = maxSubarrayBruteForce(arr, size);
        end = clock();
        bruteForceTime = (double)(end - start) / CLOCKS_PER_SEC;

        // Divide and Conquer
        start = clock();
        int divideConquerMax = maxSubarrayDivideConquer(arr, 0, size - 1);
        end = clock();
        divideConquerTime = (double)(end - start) / CLOCKS_PER_SEC;

        // Kadane's Algorithm
        start = clock();
        int kadaneMax = maxSubarrayKadane(arr, size);
        end = clock();
        kadaneTime = (double)(end - start) / CLOCKS_PER_SEC;

        printf("Size %d: BruteForce=%d, DivideConquer=%d, Kadane=%d\n",
               size, bruteForceMax, divideConquerMax, kadaneMax);

        fprintf(csvFile, "%d,%.6f,%.6f,%.6f\n", size, bruteForceTime, divideConquerTime, kadaneTime);
        fflush(csvFile);  // Ensure data is written immediately

        free(arr);
    }

    fclose(csvFile);
    return 0;
}
